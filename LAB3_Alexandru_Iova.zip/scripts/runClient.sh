#! /bin/bash

cd ../WordleClient
make
make run