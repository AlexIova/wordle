#! /bin/bash

cd ../WordleClient
make clean
cd ../WordleServer
make clean