#! /bin/bash

cd ../WordleServer
make
make run