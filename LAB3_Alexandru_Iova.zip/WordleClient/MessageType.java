enum MessageType {
    REGISTER,
    LOGIN,
    LOGOUT,
    PLAY,
    GAME,
    SHARE,
    SHOWSHARE,
    STATUS,
    STATISTICS,
    RESULT,
    REQ_STAT
}