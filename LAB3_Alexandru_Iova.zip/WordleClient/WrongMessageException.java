public class WrongMessageException extends Exception{
    
    public WrongMessageException(String msg) {
        super(msg);
    }

}
